
<div id='content_wrap'>
	<ol id='breadcrumb'><li><?php echo $section; ?> Home</li></ol>
	<div class='section_title'><h2>Shop has been moved!</h2></div>
<div class='acp-box'>
		<p style='font-size:16px'>Please visit our new shop location at <a href='http://shop.ng-gaming.net'>http://shop.ng-gaming.net</a>.</p>
</div>