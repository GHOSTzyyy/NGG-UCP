<div id='content_wrap'>
	<ol id='breadcrumb'><li><?php echo $section; ?> Information</li></ol>
	<div class='section_title'><h2>Store Information</h2></div>
	<div class='acp-box'>
		<h3></h3>
		<?php 
		if(isset($_GET['page'])) {
			if($_GET['page'] == 'rewards') {
			?>
			<table cellpadding='0' class='double_pad' cellspacing='0' border='1' width='100%' style='border-color:#ccc;'>
				<tr>
					<td>
					<div id="content"> <h1>NGG REWARDS</h1>
					<p style="text-align: left; ">
					<strong><em><span style="font-family:lucida sans unicode,lucida grande,sans-serif;"><span style="font-size:26px;">NGG Rewards is a great way to get more free stuff just by shopping with us!</span></span></em></strong></p>
					<p style="text-align: left; ">
					<span style="font-size:16px;">Some restrictions do apply, however, in most cases an item cost 3x in points that which it cost&#39;s in dollars. From time to time we may offer special bonus points on items or offer them at a reduced point purchase rate!</span></p>
					<p style="text-align: left; ">
					<span style="font-size:16px;">(Example: a $5 car would cost 15 Reward Points)</span></p>
					<p style="text-align: left; ">
					&nbsp;</p>
					<p>
					<strong><em>How much will you earn? Take a look at the chart below!!</em></strong></p>
					<p style="text-align: left; ">
					&nbsp;</p>
					<div style="background-color: transparent; ">
					<div id="internal-source-marker_0.8944504468236119">
					<table style="border-top-style: none; border-right-style: none; border-bottom-style: none; border-left-style: none; border-width: initial; border-color: initial; border-collapse: collapse; ">
					<tbody>
					<tr style="height: 0px; ">
					<td style="border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px;   vertical-align: top; padding-top: 7px; padding-right: 7px; padding-bottom: 7px; padding-left: 7px; ">
					<p dir="ltr" style="text-align: left; margin-top: 0pt; margin-bottom: 0pt; ">
					<span class="Apple-style-span" style="color: rgb(0, 0, 0); font-family: 'Times New Roman'; font-size: medium; "><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap; ">Product Dollar Amount</span></span></p>
					</td>
					<td style="border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px;   vertical-align: top; padding-top: 7px; padding-right: 7px; padding-bottom: 7px; padding-left: 7px; ">
					<p dir="ltr" style="text-align: left; margin-top: 0pt; margin-bottom: 0pt; ">
					<span class="Apple-style-span" style="color: rgb(0, 0, 0); font-family: 'Times New Roman'; font-size: medium; "><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap; ">Points Rewarded</span></span></p>
					</td>
					</tr>
					<tr style="height: 0px; ">
					<td style="border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px;   vertical-align: top; padding-top: 7px; padding-right: 7px; padding-bottom: 7px; padding-left: 7px; ">
					<p dir="ltr" style="text-align: left; margin-top: 0pt; margin-bottom: 0pt; ">
					<span class="Apple-style-span" style="color: rgb(0, 0, 0); font-family: 'Times New Roman'; font-size: medium; "><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap; ">$.01-$5</span></span></p>
					</td>
					<td style="border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px;   vertical-align: top; padding-top: 7px; padding-right: 7px; padding-bottom: 7px; padding-left: 7px; ">
					<p dir="ltr" style="text-align: left; margin-top: 0pt; margin-bottom: 0pt; ">
					<span class="Apple-style-span" style="color: rgb(0, 0, 0); font-family: 'Times New Roman'; font-size: medium; "><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap; ">1</span></span></p>
					</td>
					</tr>
					<tr style="height: 0px; ">
					<td style="border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px;   vertical-align: top; padding-top: 7px; padding-right: 7px; padding-bottom: 7px; padding-left: 7px; ">
					<p dir="ltr" style="text-align: left; margin-top: 0pt; margin-bottom: 0pt; ">
					<span class="Apple-style-span" style="color: rgb(0, 0, 0); font-family: 'Times New Roman'; font-size: medium; "><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap; ">$5.01-$10</span></span></p>
					</td>
					<td style="border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px;   vertical-align: top; padding-top: 7px; padding-right: 7px; padding-bottom: 7px; padding-left: 7px; ">
					<p dir="ltr" style="text-align: left; margin-top: 0pt; margin-bottom: 0pt; ">
					<span class="Apple-style-span" style="color: rgb(0, 0, 0); font-family: 'Times New Roman'; font-size: medium; "><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap; ">2</span></span></p>
					</td>
					</tr>
					<tr style="height: 0px; ">
					<td style="border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px;   vertical-align: top; padding-top: 7px; padding-right: 7px; padding-bottom: 7px; padding-left: 7px; ">
					<p dir="ltr" style="text-align: left; margin-top: 0pt; margin-bottom: 0pt; ">
					<span class="Apple-style-span" style="color: rgb(0, 0, 0); font-family: 'Times New Roman'; font-size: medium; "><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap; ">$10.01-$20</span></span></p>
					</td>
					<td style="border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px;   vertical-align: top; padding-top: 7px; padding-right: 7px; padding-bottom: 7px; padding-left: 7px; ">
					<p dir="ltr" style="text-align: left; margin-top: 0pt; margin-bottom: 0pt; ">
					<span class="Apple-style-span" style="color: rgb(0, 0, 0); font-family: 'Times New Roman'; font-size: medium; "><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap; ">3</span></span></p>
					</td>
					</tr>
					<tr style="height: 0px; ">
					<td style="border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px;   vertical-align: top; padding-top: 7px; padding-right: 7px; padding-bottom: 7px; padding-left: 7px; ">
					<p dir="ltr" style="text-align: left; margin-top: 0pt; margin-bottom: 0pt; ">
					<span class="Apple-style-span" style="color: rgb(0, 0, 0); font-family: 'Times New Roman'; font-size: medium; "><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap; ">$20.01-$30</span></span></p>
					</td>
					<td style="border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px;   vertical-align: top; padding-top: 7px; padding-right: 7px; padding-bottom: 7px; padding-left: 7px; ">
					<p dir="ltr" style="text-align: left; margin-top: 0pt; margin-bottom: 0pt; ">
					<span class="Apple-style-span" style="color: rgb(0, 0, 0); font-family: 'Times New Roman'; font-size: medium; "><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap; ">4</span></span></p>
					</td>
					</tr>
					<tr style="height: 0px; ">
					<td style="border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px;   vertical-align: top; padding-top: 7px; padding-right: 7px; padding-bottom: 7px; padding-left: 7px; ">
					<p dir="ltr" style="text-align: left; margin-top: 0pt; margin-bottom: 0pt; ">
					<span class="Apple-style-span" style="color: rgb(0, 0, 0); font-family: 'Times New Roman'; font-size: medium; "><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap; ">$30-$99.99</span></span></p>
					</td>
					<td style="border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px;   vertical-align: top; padding-top: 7px; padding-right: 7px; padding-bottom: 7px; padding-left: 7px; ">
					<p dir="ltr" style="text-align: left; margin-top: 0pt; margin-bottom: 0pt; ">
					<span class="Apple-style-span" style="color: rgb(0, 0, 0); font-family: 'Times New Roman'; font-size: medium; "><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap; ">5</span></span></p>
					</td>
					</tr>
					<tr style="height: 0px; ">
					<td style="border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px;   vertical-align: top; padding-top: 7px; padding-right: 7px; padding-bottom: 7px; padding-left: 7px; ">
					<p dir="ltr" style="text-align: left; margin-top: 0pt; margin-bottom: 0pt; ">
					<span class="Apple-style-span" style="color: rgb(0, 0, 0); font-family: 'Times New Roman'; font-size: medium; "><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap; ">$100+</span></span></p>
					</td>
					<td style="border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px;   vertical-align: top; padding-top: 7px; padding-right: 7px; padding-bottom: 7px; padding-left: 7px; ">
					<p dir="ltr" style="text-align: left; margin-top: 0pt; margin-bottom: 0pt; ">
					<span class="Apple-style-span" style="color: rgb(0, 0, 0); font-family: 'Times New Roman'; font-size: medium; "><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap; ">6</span></span></p>
					</td>
					</tr>
					</tbody>
					</table>
					<p>
					*Reward Point Purchase Rates are based on normal, not sale, prices.</p>
					</div>
					</div>
					</td>
				</tr>
			</table>
			<?php
			}
			if($_GET['page'] == 'terms') {
			?>
			<table cellpadding='0' cellspacing='0' border='1' width='100%' style='border-color:#ccc;'>
				<tr>
					<td>
					<div id="content">
					<p>
					<span style="font-weight: bold; text-decoration: underline; ">NGG Terms and Conditions</span>
					</p>
					<p>
					<br/>
					<ol>
					<li>All sales are final.</li>
					<li>All sales are non-refundable (unless outlined otherwise below or by special agreement prior to purchase)</li>
					<li>All sales are non-transferable.</li>
					<li>All VIP Features are strictly able to be used from the date of payment (Central Standard Time) until 12:01AM one month from that date of payment irregardless of your player status (being inactive, banned or etc.).</li>
					<li>Being a VIP does not lessen the rules or their punishments for a player. The rules will be enforced equally to all players and as such, if you become banned, no refunds or hold's on your time will be issued.</li>
					<li>The $100 one time cost of gold does include the first month of service, beyond that you must subscribe to the Gold Plan ($12 Monthly).</li>
					<li>If you wish to upgrade/downgrade your VIP please contact <a class="__cf_email__" href="http://www.cloudflare.com/email-protection" data-cfemail="4123282d2d282f26012f266c26202c282f266f2f2435">[email&nbsp;protected]</a><script type="text/javascript">
					/* <![CDATA[ */
					(function(){try{var s,a,i,j,r,c,l,b=document.getElementsByTagName("script");l=b[b.length-1].previousSibling;a=l.getAttribute('data-cfemail');if(a){s='';r=parseInt(a.substr(0,2),16);for(j=2;a.length-j;j+=2){c=parseInt(a.substr(j,2),16)^r;s+=String.fromCharCode(c);}s=document.createTextNode(s);l.parentNode.replaceChild(s,l);}}catch(e){}})();
					/* ]]> */
					</script> prior to making any changes on this page.</li>
					<li>All purchases are one-time only unless specified otherwise.</li>
					<li>If you stop your VIP subscription, all VIP items will be removed from your account, without an in-game refund (i.e. for VIP Cars you purchased, etc).</li>
					<li>Abuse of certain VIP features, such as but not limited to, VIP Chat or exploiting other VIP features could result in temporary or complete loss of those privileges without refund.</li>
					<li>Your product will not be issued until paid in full (i.e. e-checks sometimes take up to 1 week to clear).</li>
					<li>If your payment becomes �held� by Paypal for account/security related issues your purchase could be revoked or suspended until all issues are cleared with Pay Pal and the money is no longer frozen in the account.</li>
					<li>All efforts should be made contacting our staff before �charging back� on pay pal. Any person who charges could be completely banned from the community without refund for any purchases if it is done so maliciously.</li>
					<li>If you are&nbsp;permanently banned any item purchased beyond 30 days prior to the ban will not be refunded. All other purchases excluding VIP's, Custom Cars and Gates can be refunded from the 30 days prior to the ban. &nbsp; &nbsp; &nbsp; Otherwise you agree, that if you become banned from the server and/or community for any reason that no refunds will be issued.</li>
					<li>If your order total is over $50 it may be held for up to 3 days to preform security checks.</li>
					<li>All orders will not be issued until cleared by thier respective payment services.</li>
					<li>Certain items or features of certain items and/or packages may change with or without notice and may vary based on scripting revisions then how the item is listed on our site. Substitutions, credits, or refunds may or may not be offered and issued because of this.</li>
					<li>If you charge back items, your account will become banned in the entire community. In order to become unbanned you must pay the total amount charged back, any chargeback fee's we may have been charged by the payment service and a 10% service fee for the time it took to deal with the matter over time.</li>
					</ol>
					</td>
				</tr>
			</table>
			<?php 
			}
			if($_GET['page'] == 'policy') {
			?>
			<table cellpadding='0' cellspacing='0' border='1' width='100%' style='border-color:#ccc;'>
				<tr>
					<td>
					<div id="content"> <h1>Privacy Policy</h1>
					<p>
					Privacy Policy</p>
					<h1 id="privacyDefaultHeading" style="font-size: 1.2em; color: rgb(0, 0, 0); margin-top: 0.3em; margin-right: 0.3em; margin-bottom: 0.3em; margin-left: 0px; ">
					<span class="Apple-style-span" style="color: rgb(51, 51, 51); font-family: tahoma, sans-serif; ">Privacy Notice</span></h1>
					<div class="content" id="privacyDefaultMainContent">
					<span class="Apple-style-span" style="color: rgb(51, 51, 51); font-family: tahoma, sans-serif; ">This privacy notice discloses the privacy practices for (ng-gaming.net). This privacy notice applies solely to information collected by this web site. It will notify you of the following:<br/>
					<br/>
					&nbsp;&nbsp; 1. What personally identifiable information is collected from you through the web site, how it is used and with whom it may be shared.<br/>
					&nbsp;&nbsp; 2. What choices are available to you regarding the use of your data.<br/>
					&nbsp;&nbsp; 3. The security procedures in place to protect the misuse of your information.<br/>
					&nbsp;&nbsp; 4. How you can correct any inaccuracies in the information.&nbsp;<br/>
					<br/>
					<span style="font-weight: bold; ">Information Collection, Use, and Sharing</span><br/>
					We are the sole owners of the information collected on this site. We only have access to/collect information that you voluntarily give us via email or other direct contact from you. We will not sell or rent this information to anyone.<br/>
					<br/>
					We will use your information to respond to you, regarding the reason you contacted us. We will not share your information with any third party outside of our organization, other than as necessary to fulfill your request, e.g. to ship an order.<br/>
					<br/>
					Unless you ask us not to, we may contact you via email in the future to tell you about specials, new products or services, or changes to this privacy policy.<br/>
					<br/>
					<span style="font-weight: bold; ">Your Access to and Control Over Information</span><br/>
					You may opt out of any future contacts from us at any time. You can do the following at any time by contacting us via the email address or phone number given on our website:<br/>
					</span>
					<ul>
					<li>
					<span class="Apple-style-span" style="color: rgb(51, 51, 51); font-family: tahoma, sans-serif; ">See what data we have about you, if any.</span></li>
					<li>
					<span class="Apple-style-span" style="color: rgb(51, 51, 51); font-family: tahoma, sans-serif; ">Change/correct any data we have about you.</span></li>
					<li>
					<span class="Apple-style-span" style="color: rgb(51, 51, 51); font-family: tahoma, sans-serif; ">Have us delete any data we have about you.</span></li>
					<li>
					<span class="Apple-style-span" style="color: rgb(51, 51, 51); font-family: tahoma, sans-serif; ">Express any concern you have about our use of your data.&nbsp;<br/>
					</span></li>
					</ul>
					<br>
					<span class="Apple-style-span" style="color: rgb(51, 51, 51); font-family: tahoma, sans-serif; "><span style="font-weight: bold; ">Security</span><br/>
					We take precautions to protect your information. When you submit sensitive information via the website, your information is protected both online and offline.<br/>
					<br/>
					Wherever we collect sensitive information (such as credit card data), that information is encrypted and transmitted to us in a secure way. You can verify this by looking for a closed lock icon at the bottom of your web browser, or looking for &quot;https&quot; at the beginning of the address of the web page.<br/>
					<br/>
					While we use encryption to protect sensitive information transmitted online, we also protect your information offline. Only employees who need the information to perform a specific job (for example, billing or customer service) are granted access to personally identifiable information. The computers/servers in which we store personally identifiable information are kept in a secure environment.<br/>
					<br/>
					If you feel that we are not abiding by this privacy policy, you should contact us immediately at <a class="__cf_email__" href="http://www.cloudflare.com/email-protection" data-cfemail="06646f6a6a6f68614668612b61676b6f686128686372">[email&nbsp;protected]</a><script type="text/javascript">
					/* <![CDATA[ */
					(function(){try{var s,a,i,j,r,c,l,b=document.getElementsByTagName("script");l=b[b.length-1].previousSibling;a=l.getAttribute('data-cfemail');if(a){s='';r=parseInt(a.substr(0,2),16);for(j=2;a.length-j;j+=2){c=parseInt(a.substr(j,2),16)^r;s+=String.fromCharCode(c);}s=document.createTextNode(s);l.parentNode.replaceChild(s,l);}}catch(e){}})();
					/* ]]> */
					</script></span></div>
					</td>
				</tr>
			</table>
			<?php } 
		}?>
	</div>
</div>