<meta name="description" content="Next Generation Gaming's Content Management System">
<meta name="keywords" content="ngg, cms, ngrp, next generation gaming, content management system">
<link rel="shortcut icon" href="http://<?php echo $_SERVER['SERVER_NAME']; ?>/favicon.ico" type="image/x-icon" />
<title>Next Generation Gaming CP</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="http://<?php echo $_SERVER['SERVER_NAME']; ?>/global/css/acp.css">
<link rel="stylesheet" type="text/css" href="http://<?php echo $_SERVER['SERVER_NAME']; ?>/global/css/acp_content.css">
<link rel="stylesheet" type="text/css" href="http://<?php echo $_SERVER['SERVER_NAME']; ?>/global/css/acp_ie_tweaks.css">
<link rel="stylesheet" type="text/css" href="http://<?php echo $_SERVER['SERVER_NAME']; ?>/global/css/nav.css" />
<!-- <link rel="stylesheet" type="text/css" href="http://<?php echo $_SERVER['SERVER_NAME']; ?>/global/css/bootstrap.min.css" /> !-->


<script type="text/javascript" src="http://<?php echo $_SERVER['SERVER_NAME']; ?>/global/js/nav_motion.js"></script>
<script language="javascript" src="http://<?php echo $_SERVER['SERVER_NAME']; ?>/global/js/calendar.js"></script>
<script type="text/javascript">var _gaq=_gaq||[];_gaq.push(["_setAccount","UA-24622712-1"]);_gaq.push(["_trackPageview"]);(function(){var e=document.createElement("script");e.type="text/javascript";e.async=true;e.src=("https:"==document.location.protocol?"http://ssl":"http://www")+".google-analytics.com/ga.js";var t=document.getElementsByTagName("script")[0];t.parentNode.insertBefore(e,t)})()</script>