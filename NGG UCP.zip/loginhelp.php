<style>
body {
	background: #d3dae0 url(http://<?php echo $_SERVER['SERVER_NAME']; ?>/global/images/all/branding_bg.png) repeat-x top;
}
</style>
<title>CP Login Help</title>
<img style='margin-top:-9px;' src="http://cp.ng-gaming.net/global/images/all/logo.png" alt="Logo">
<ul>
	<li>Go to <a href='http://cp.ng-gaming.net'>http://cp.ng-gaming.net</a></li>
	<li>When it brings you to the login page. Put in your roleplay name (name of your account, example: John_Smith) in the Username field.</li>
	<li>Then place the password associated with that account in the password field.</li>
	<li>Then click on the Login button, and it will take you to your dashboard where you can continue to use the Control Panel to see your statistics, edit account information, and view and use other
	tools the Control Panel has.</li>
</ul>