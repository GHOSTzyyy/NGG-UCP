<?php require('../../global/func.php');
$redir = '<meta http-equiv="refresh" content="0;url=../login.php">';
$assignredir = '<meta http-equiv="refresh" content="0;url=../index.php?p=shift">';
$removeredir = '<meta http-equiv="refresh" content="0;url=../index.php?p=dashboard">';
if(!isset($_SESSION['myusername'])){
$logged = 0;
echo $redir;
exit();
}

//----Variables
$section = "Staff";
$area = "Shifts";
$action = $_POST['action'];
$admin = $_POST['admin'];
$userid = $_POST['userid'];
$shiftid = $_POST['shiftid'];
$shiftblock = $_POST['shiftblock'];
$assigndate = $_POST['assigndate'];
$ip = $_POST['ip'];
$date = date('Y-m-d');
$diff = strtotime("$assigndate") - strtotime("$date");
$num = $diff/86400;
$days = intval($num);
//-------End Variables

if(strtolower($admin) != strtolower($inf['Username'])) { echo "Data tampered with. ERR:001"; exit(); }
if($ip != $_SERVER['REMOTE_ADDR']) { echo "Data tampered with. ERR:002"; exit(); }

if($action == "assign") {
foreach ($shiftid as $shift) {
if ($_GET['assign'] == 'advisor') {
if($days > 4) {
$assignquery = "INSERT INTO `cp_shifts` (`id`, `user_id`, `type`, `shift_id`, `date`, `sign_up`, `status`, `bonus`) VALUES (NULL, '$userid', 3, '$shift', '$assigndate', '$date', '2', '2')";
}
else {
$assignquery = "INSERT INTO `cp_shifts` (`id`, `user_id`, `type`, `shift_id`, `date`, `sign_up`, `status`, `bonus`) VALUES (NULL, '$userid', 3, '$shift', '$assigndate', '$date', '2', '0')";
}
}
if ($_GET['assign'] == 'admin') {
if($days > 4) {
$assignquery = "INSERT INTO `cp_shifts` (`id`, `user_id`, `type`, `shift_id`, `date`, `sign_up`, `status`, `bonus`) VALUES (NULL, '$userid', 1, '$shift', '$assigndate', '$date', '2', '2')";
}
else {
$assignquery = "INSERT INTO `cp_shifts` (`id`, `user_id`, `type`, `shift_id`, `date`, `sign_up`, `status`, `bonus`) VALUES (NULL, '$userid', 1, '$shift', '$assigndate', '$date', '2', '0')";
}
}
$runquery = mysql_query($assignquery);
echo $assignredir;

if (!$runquery) {
    $message  = 'Invalid query: ' . mysql_error() . "\n";
    $message .= 'Whole query: ' . $assignquery;
    die($message);
	}
}
}

if($action == "removeshift") {
if ($inf['AdminLevel'] >= 2) {
$removeshiftquery = "UPDATE `cp_shifts` SET `status` = '1' WHERE `id` = '$shiftid' AND `type`='1'";
} else {
$removeshiftquery = "UPDATE `cp_shifts` SET `status` = '1' WHERE `id` = '$shiftid' AND `type`='3'";
}
$runquery = mysql_query($removeshiftquery);
$details = "Removed self from ".$shiftblock." shift on ".$assigndate;
doLog($inf['id'], $section, $area, $details);
echo $removeredir;

if (!$runquery) {
    $message  = 'Invalid query: ' . mysql_error() . "\n";
    $message .= 'Whole query: ' . $removeshiftquery;
    die($message);
	}
}
?>