<?php if($inf['Security'] < 0 || $inf['AdminLevel'] < 1338 && isset($redir2)) {
	echo $redir2;
	exit();
}
?>

			<div id='content_wrap'>
				<ol id='breadcrumb'><li>Security</li></ol>
				<div class='section_title'><h2>Security</h2></div>
			<div class='acp-box'>
				<h3>Security Management</h3>
					<p>Use the navigation on the left for Security management.</p>
	<div class='acp-actionbar'></div>
			</div></div>