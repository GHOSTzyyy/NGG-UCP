<?php
	if($inf['AdminLevel'] < 3) {
	echo $redir2;
	exit();
	}
?>

			<div id='content_wrap'>
The username you selected is already in use. Please check the <a href="user.php?p=view&g=disabled" style="font-weight:bold">Disabled users section</a> to restore the account, or <a href="javascript:history.go(-1)" style="font-weight:bold">go back and choose another username</a>.
			</div>