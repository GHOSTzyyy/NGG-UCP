<?php if($inf['AdminLevel'] < 1338 && $inf['Helper'] < 3 && isset($redir2)) {
	echo $redir2;
	exit();
}
?>

			<div id='content_wrap'>
				<ol id='breadcrumb'><li>User Management</li></ol>
				<div class='section_title'><h2>User Management</h2></div>
			<div class='acp-box'>
				<h3>User Management</h3>
					<p>Use the navigation on the left for user management.</p>
	<div class='acp-actionbar'></div>
			</div></div>