<?php if($inf['AdminLevel'] < 1337 || $inf['PR'] == 0 && isset($redir2)) {
	echo $redir2;
	exit();
}
?>

			<div id='content_wrap'>
				<ol id='breadcrumb'><li>Public Relations</li></ol>
				<div class='section_title'><h2>Public Relations</h2></div>
			<div class='acp-box'>
				<h3>Public Relations Management</h3>
					<p>Use the navigation on the left for Public Relations management.</p>
	<div class='acp-actionbar'></div>
			</div></div>