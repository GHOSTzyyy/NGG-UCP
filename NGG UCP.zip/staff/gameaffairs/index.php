<?php if($inf['FactionModerator'] < 0 || $inf['GangModerator'] < 0 || $inf['AdminLevel'] < 1338 && isset($redir2)) {
	echo $redir2;
	exit();
}
?>

			<div id='content_wrap'>
				<ol id='breadcrumb'><li>Game Affairs</li></ol>
				<div class='section_title'><h2>Game Affairs</h2></div>
			<div class='acp-box'>
				<h3>Game Affairs Management</h3>
					<p>Use the navigation on the left for Game Affairs management.</p>
	<div class='acp-actionbar'></div>
			</div></div>