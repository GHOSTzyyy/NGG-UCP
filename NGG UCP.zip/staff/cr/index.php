<?php if($inf['AdminLevel'] < 1337 || $inf['ShopTech'] == 0 && isset($redir2)) {
	echo $redir2;
	exit();
}
?>

			<div id='content_wrap'>
				<ol id='breadcrumb'><li>Customer Relations</li></ol>
				<div class='section_title'><h2>Customer Relations</h2></div>
			<div class='acp-box'>
				<h3>Customer Relations Management</h3>
					<p>Use the navigation on the left for Customer Relations management.</p>
	<div class='acp-actionbar'></div>
			</div></div>