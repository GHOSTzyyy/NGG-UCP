<?php
//alexcss
$img = "http://www.imgbomb.com/new/";
echo '<script src="http://code.jquery.com/jquery-latest.js"></script>';
echo '<style type="text/css"> .prev{ background-image:url('.$img.'prev1.png); width: 200px; height: 30px; display: block; } .prev:hover{ background-image:url('.$img.'prev2.png); width: 200px; height: 30px; display: block; }';
echo '.next{ background-image:url('.$img.'next1.png); width: 200px; height: 30px; display: block; } .next:hover{ background-image:url('.$img.'next2.png); width: 200px; height: 30px; display: block; } ';
echo '.cmsl{ background-image:url(global/images/cms1.png); width: 200px; height: 30px; display: block; }.cmsl:hover{ background-image:url(global/images/cms2.png); width: 200px; height: 30px; display: block; } ';
echo '.bk{ background-image:url(global/images/back.png); width: 30px; height: 30px; display: block; }.bk:hover{ background-image:url(global/images/back1.png); width: 30px; height: 30px; display: block; } ';
echo '.cls{ background-image:url(global/images/CloseButton.png); width: 22px; height: 22px; display: block; }.cls:hover{ background-image:url(global/images/CloseButton_dn.png); width: 22px; height: 22px; display: block; } ';

echo '.tbl{ background-image:url(global/images/blank.png); width: 300px; height: 30px; display: block; }.tbl:hover{ background-image:url(global/images/blank1.png); cursor:hand; width: 300px; height: 30px; display: block; } ';
echo '.tbles{ background-image:url(global/images/blankes.png); width: 64px; height: 30px; display: block; }.tbles:hover{ background-image:url(global/images/blankes1.png); cursor:hand; width: 64px; height: 30px; display: block; } ';
echo '.tbls{ background-image:url(global/images/blanks.png); width: 200px; height: 30px; display: block; }.tbls:hover{ background-image:url(global/images/blanks1.png); cursor:hand; width: 200px; height: 30px; display: block; } </style>';
	
echo '<script type="text/javascript">';
echo 'function show(id) {';
echo 'document.getElementById(id).style.display = \'block\';';
echo '}'; 
echo 'function hide(id) {';
echo 'document.getElementById(id).style.display = \'none\';';
echo '}';
echo '</script>';

?>